//
//  ViewController.swift
//  UIStepperController_Example
//
//  Created by Nadeeshan Jayawardana on 6/21/18.
//  Copyright © 2018 NEngineering. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIStepperControllerDelegate {
    
    // Implement UIStepperController instance as Subview of your ViewController
    let stepperController01: UIStepperController = UIStepperController(frame: CGRect(x: 113, y: 150, width: 150, height: 32))
    
    
    // Implement UIStepperController instance as IBOutlet
    @IBOutlet var stepperController02: UIStepperController!
    @IBOutlet var stepperController03: UIStepperController!
    @IBOutlet var stepperController04: UIStepperController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Implement UIStepperController instance as Subview of your ViewController
        
        self.stepperController01.delegate = self // Assign instance delegate to UIStepperControllerDelegate
        self.stepperController01.tag = 10001 // Assign tag to Identify UIStepperController
        self.view.addSubview(stepperController01);
        
        
        // Implement UIStepperController instance as IBOutlet
        
        self.stepperController02.delegate = self // Assign instance delegate to UIStepperControllerDelegate
        self.stepperController02.tag = 10002 // Assign tag to Identify UIStepperController
        self.stepperController02.isFloat = true
        self.stepperController02.borderColor(color: .red)
        self.stepperController02.incrementBy(number: 0.1)
        self.stepperController02.count = 0
        
        
        self.stepperController03.delegate = self // Assign instance delegate to UIStepperControllerDelegate
        self.stepperController03.tag = 10003 // Assign tag to Identify UIStepperController
        self.stepperController03.isFloat = true
        self.stepperController03.isMinus = true
        self.stepperController03.textColor(color: .darkText)
        self.stepperController03.incrementBy(number: 20.5)
        self.stepperController03.count = 100.30
        
        
        self.stepperController04.delegate = self // Assign instance delegate to UIStepperControllerDelegate
        self.stepperController04.tag = 10004 // Assign tag to Identify UIStepperController
        self.stepperController04.isMinus = true
        self.stepperController04.textColor(color: .white)
        self.stepperController04.borderColor(color: UIColor(red: 1.0, green: 0.68, blue: 0.0, alpha: 1.0))
        self.stepperController04.backgroundColor(color: .darkGray)
        self.stepperController04.incrementBy(number: 1)
        self.stepperController04.count = -10
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UIStepperControllerDelegate functions

    func stepperDidAddValues(stepper: UIStepperController) {
        switch stepper.tag {
            case 10001:
                print("Stepper 10001 value did change (Add) : \(stepper.count)")
                break
            case 10002:
                print("Stepper 10002 value did change (Add) : \(stepper.count)")
                break
            case 10003:
                print("Stepper 10003 value did change (Add) : \(stepper.count)")
                break
            case 10004:
                print("Stepper 10004 value did change (Add) : \(stepper.count)")
                break
        default:
            break
        }
    }
    
    func stepperDidSubtractValues(stepper: UIStepperController) {
        switch stepper.tag {
            case 10001:
                print("Stepper 10001 value did change (Subtract) : \(stepper.count)")
                break
            case 10002:
                print("Stepper 10002 value did change (Subtract) : \(stepper.count)")
                break
            case 10003:
                print("Stepper 10003 value did change (Subtract) : \(stepper.count)")
                break
            case 10004:
                print("Stepper 10004 value did change (Subtract) : \(stepper.count)")
                break
        default:
            break
        }
    }

}

